/* app.jsx — root: parallax, reveals, scroll progress, gallery state, tweaks */
const { useState, useEffect, useRef, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": ["#38BDF8", "#22D3EE", "#2563EB"],
  "gradStrength": 1,
  "motion": 1,
  "displayFont": "Space Grotesk",
  "grid": true
}/*EDITMODE-END*/;

const PALETTES = [
  ["#38BDF8", "#22D3EE", "#2563EB"], // brand sky→cyan→blue
  ["#5eead4", "#22D3EE", "#0ea5e9"], // aqua / teal
  ["#818cf8", "#38BDF8", "#4f46e5"], // periwinkle
  ["#7dd3fc", "#67e8f9", "#1d4ed8"], // ice
];
const FONTS = ["Space Grotesk", "Schibsted Grotesk", "Sora"];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [loaded, setLoaded] = useState(false);
  const [openIndex, setOpenIndex] = useState(null);

  /* ----- apply tweaks to :root ----- */
  useEffect(() => {
    const r = document.documentElement.style;
    const [p, s, d] = t.palette || PALETTES[0];
    r.setProperty("--c-primary", p);
    r.setProperty("--c-secondary", s);
    r.setProperty("--c-deep", d);
    r.setProperty("--grad-strength", String(t.gradStrength));
    r.setProperty("--motion", String(t.motion));
    r.setProperty("--font-display", `'${t.displayFont}', 'Zen Kaku Gothic New', sans-serif`);
  }, [t]);

  /* ----- loader ----- */
  useEffect(() => {
    const id = setTimeout(() => setLoaded(true), 1500);
    return () => clearTimeout(id);
  }, []);

  /* ----- reveals ----- */
  useEffect(() => {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.16, rootMargin: "0px 0px -8% 0px" });
    document.querySelectorAll(".reveal:not(.in)").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [loaded]);

  /* ----- scroll progress + nav state ----- */
  useEffect(() => {
    const bar = document.getElementById("progress");
    const nav = document.getElementById("nav");
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      const p = h > 0 ? window.scrollY / h : 0;
      if (bar) bar.style.transform = `scaleX(${p})`;
      if (nav) nav.classList.toggle("scrolled", window.scrollY > 40);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* ----- parallax (scroll + mouse) ----- */
  useEffect(() => {
    const els = [...document.querySelectorAll("[data-par]")].filter((e) => !e.classList.contains("blob"));
    let mx = 0, my = 0, raf = 0;
    const apply = () => {
      const sy = window.scrollY;
      els.forEach((el) => {
        const d = parseFloat(el.dataset.par) || 0;
        const tx = mx * d * 46;
        const ty = sy * d + my * d * 46;
        el.style.transform = `translate3d(${tx.toFixed(1)}px, ${ty.toFixed(1)}px, 0)`;
      });
      raf = 0;
    };
    const req = () => { if (!raf) raf = requestAnimationFrame(apply); };
    const onMove = (e) => {
      mx = (e.clientX / window.innerWidth - 0.5) * 2;
      my = (e.clientY / window.innerHeight - 0.5) * 2;
      req();
    };
    window.addEventListener("scroll", req, { passive: true });
    window.addEventListener("mousemove", onMove, { passive: true });
    apply();
    return () => { window.removeEventListener("scroll", req); window.removeEventListener("mousemove", onMove); };
  }, []);

  /* ----- smooth jump (no scrollIntoView) ----- */
  const jump = useCallback((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const y = el.getBoundingClientRect().top + window.scrollY - (id === "top" ? 0 : 72);
    window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
  }, []);

  /* ----- gallery ----- */
  const open = useCallback((i) => { setOpenIndex(i); }, []);
  const close = useCallback(() => setOpenIndex(null), []);
  const nav = useCallback((dir) => {
    setOpenIndex((i) => (i == null ? i : (i + dir + PUBLICATIONS.length) % PUBLICATIONS.length));
  }, []);

  useEffect(() => {
    document.body.classList.toggle("locked", openIndex != null);
    if (openIndex == null) return;
    const onKey = (e) => {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowRight") nav(1);
      else if (e.key === "ArrowLeft") nav(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, nav]);

  return (
    <React.Fragment>
      <div className={"loader" + (loaded ? " gone" : "")}>
        <div className="loader__inner">
          <div className="draw"><Logo size={64} stroke={2.6} /></div>
          <div className="loader__bar"><i /></div>
          <div className="loader__txt">Initializing Lab.</div>
        </div>
      </div>

      <div className="scroll-progress" id="progress" />

      <Nav onJump={jump} />
      <main>
        <Hero onJump={jump} />
        <Marquee />
        <About />
        <Publications onOpen={open} />
        <Events />
      </main>
      <Footer onJump={jump} />

      {openIndex != null && (
        <Experience
          pub={PUBLICATIONS[openIndex]}
          index={openIndex}
          total={PUBLICATIONS.length}
          onClose={close}
          onNav={nav}
        />
      )}

      <TweaksPanel>
        <TweakSection label="Palette" />
        <TweakColor label="Gradient" value={t.palette}
          options={PALETTES}
          onChange={(v) => setTweak("palette", v)} />
        <TweakSlider label="Gradient intensity" value={t.gradStrength} min={0.4} max={1.4} step={0.1}
          onChange={(v) => setTweak("gradStrength", v)} />

        <TweakSection label="Motion" />
        <TweakSlider label="Animation speed" value={t.motion} min={0.4} max={1.8} step={0.1} unit="×"
          onChange={(v) => setTweak("motion", v)} />

        <TweakSection label="Typography" />
        <TweakSelect label="Display font" value={t.displayFont} options={FONTS}
          onChange={(v) => setTweak("displayFont", v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
