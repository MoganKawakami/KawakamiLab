/* data.jsx — publications + reusable placeholder art */

/* Striped, gradient-tinted placeholder per imagery guidance.
   ratio controls the cover proportion; label is the monospace explainer. */
function Placeholder({ ratio = 1.4, label = "COVER", from = "var(--c-primary)", to = "var(--c-deep)", sub, big = false }) {
  return (
    <div className="ph" style={{
      position: "relative", width: "100%", aspectRatio: String(1 / ratio),
      background: `linear-gradient(135deg, ${from}, ${to})`,
      display: "grid", placeItems: "center", overflow: "hidden"
    }}>
      <div style={{
        position: "absolute", inset: 0, opacity: .5, mixBlendMode: "soft-light",
        backgroundImage: "repeating-linear-gradient(135deg, rgba(255,255,255,.5) 0 1px, transparent 1px 11px)"
      }} />
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(120% 90% at 80% 0%, rgba(255,255,255,.32), transparent 55%)"
      }} />
      {/* corner ticks — lab specimen framing */}
      <svg style={{ position: "absolute", inset: 12, width: "calc(100% - 24px)", height: "calc(100% - 24px)" }} fill="none">
        <path d="M0 14V0h14M100% 14V0h-14" stroke="rgba(255,255,255,.6)" strokeWidth="1.4"
              transform="" />
      </svg>
      <div style={{ position: "relative", textAlign: "center", color: "#fff", padding: 20 }}>
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: big ? 13 : 10.5, letterSpacing: ".22em",
          textTransform: "uppercase", opacity: .92
        }}>{label}</div>
        {sub && <div style={{
          fontFamily: "var(--font-jp)", fontSize: big ? 18 : 13, marginTop: 8, opacity: .85, fontWeight: 500
        }}>{sub}</div>}
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: 9, letterSpacing: ".2em", marginTop: 12,
          opacity: .6, textTransform: "uppercase"
        }}>drop artwork here</div>
      </div>
    </div>
  );
}

const PUBLICATIONS = [
  {
    id: "chroma", title: "CHROMA", jp: "彩光", year: "2024", ratio: 1.42,
    type: "Art Book", price: "¥2,400", priceJp: "頒布価格",
    event: "COMITIA 148", date: "2024.05.05", format: "A4 / 64P / Full Color",
    from: "#5fc8ff", to: "#2563EB",
    tags: ["Original", "Illustration", "Full-Color", "A4"],
    desc: "An original illustration collection exploring light as material — refraction, halation, and the chromatic edges where color becomes form.",
    descJp: "光を素材として捉えたオリジナルイラスト集。屈折、ハレーション、色が形になる瞬間の彩りを収録した一冊。",
    previews: ["PLATE 01", "PLATE 02", "PLATE 03"],
  },
  {
    id: "neon", title: "NEON GARDEN", jp: "電子庭園", year: "2023", ratio: 1.3,
    type: "Illustration", price: "¥1,800", priceJp: "頒布価格",
    event: "Comic Market 103", date: "2023.12.30", format: "B5 / 48P / Full Color",
    from: "#3bd6e6", to: "#1f7fe0",
    tags: ["Original", "Digital", "B5"],
    desc: "A botanical garden rendered in circuitry and bioluminescence — where organic growth meets synthetic light.",
    descJp: "回路と発光で描いた植物園。有機的な成長と人工の光が交わる、電子の庭の記録。",
    previews: ["FLORA A", "FLORA B", "FLORA C"],
  },
  {
    id: "proto", title: "PROTOTYPE 0", jp: "試作零号", year: "2024", ratio: 1.7,
    type: "Concept / Sketch", price: "¥1,500", priceJp: "頒布価格",
    event: "COMITIA 150", date: "2024.11.24", format: "A5 / 80P / Mono",
    from: "#7dd3fc", to: "#0ea5e9",
    tags: ["Concept", "Sketch", "Process", "A5"],
    desc: "The lab notebook — rough thumbnails, line studies, and the discarded iterations behind the finished works.",
    descJp: "研究室のノート。ラフ、線の習作、完成作の裏側で捨てられた試行錯誤を綴じた一冊。",
    previews: ["STUDY 01", "STUDY 02", "STUDY 03"],
  },
  {
    id: "lumina", title: "LUMINA", jp: "光環", year: "2023", ratio: 1.45,
    type: "Art Book", price: "¥2,800", priceJp: "頒布価格",
    event: "COMITIA 146", date: "2023.09.03", format: "A4 / 72P / Hardcover",
    from: "#67e8f9", to: "#2563EB",
    tags: ["Original", "Hardcover", "Premium"],
    desc: "A hardcover anthology of luminous portraiture — figures wrapped in coronas of engineered light.",
    descJp: "発光するポートレイトのハードカバー作品集。設計された光の輪をまとう人物たちを収録。",
    previews: ["HALO 01", "HALO 02", "HALO 03"],
  },
  {
    id: "signal", title: "SIGNAL", jp: "信号", year: "2022", ratio: 1.28,
    type: "Fan Art", price: "¥1,600", priceJp: "頒布価格",
    event: "Comic Market 101", date: "2022.12.31", format: "B5 / 40P / Full Color",
    from: "#38BDF8", to: "#1e40af",
    tags: ["Fan Art", "Tribute", "B5"],
    desc: "A tribute collection — favorite characters re-imagined through the lab's chromatic lens.",
    descJp: "敬愛するキャラクターたちを、ラボの色彩で再解釈したトリビュート作品集。",
    previews: ["FRAME A", "FRAME B", "FRAME C"],
  },
  {
    id: "halation", title: "HALATION", jp: "ハレーション", year: "2025", ratio: 1.6,
    type: "Upcoming", price: "TBA", priceJp: "予価",
    event: "COMITIA 152", date: "2025.08.17", format: "A4 / TBA",
    from: "#a5f3fc", to: "#0284c7", upcoming: true,
    tags: ["Original", "Upcoming", "2025"],
    desc: "The next research cycle — an overexposed dreamscape pushing the lab's light studies to their bright limit.",
    descJp: "次の研究サイクル。露光オーバーの夢景色で、ラボの光の探究を限界の明るさまで押し進める新作。",
    previews: ["TEASER 01", "TEASER 02", "TEASER 03"],
  },
];

const EVENTS = [
  {
    id: "comitia152", name: "COMITIA 152", jp: "コミティア152",
    iso: "2026-08-17", date: "2026.08.17", weekday: "SUN",
    venue: "Tokyo Big Sight", venueJp: "東京ビッグサイト 西1・2ホール",
    booth: "あ-12b", highlight: true,
    note: "新刊『HALATION / ハレーション』先行頒布。ラボ最新の光の研究をいち早く。",
    noteEn: "Early release of HALATION — our newest light study.",
  },
  {
    id: "cm108", name: "Comic Market 108", jp: "コミックマーケット108",
    iso: "2026-08-30", date: "2026.08.30", weekday: "SUN",
    venue: "Tokyo Big Sight", venueJp: "東京ビッグサイト 東地区",
    booth: "東7 か-21a",
    note: "既刊フルラインナップ＋新作アクリルスタンド・ポストカードを頒布。",
    noteEn: "Full back-catalogue plus new acrylic stands & postcards.",
  },
  {
    id: "comitia154", name: "COMITIA 154", jp: "コミティア154",
    iso: "2026-11-23", date: "2026.11.23", weekday: "MON",
    venue: "Tokyo Big Sight", venueJp: "東京ビッグサイト 西ホール",
    booth: "TBA",
    note: "『試作零号 / PROTOTYPE 0』再版予定。ラフ集の増補版を準備中。",
    noteEn: "Reprint of PROTOTYPE 0 — expanded sketch edition.",
  },
  {
    id: "cm109", name: "Comic Market 109", jp: "コミックマーケット109",
    iso: "2026-12-31", date: "2026.12.31", weekday: "THU",
    venue: "Tokyo Big Sight", venueJp: "東京ビッグサイト 東地区",
    booth: "TBA",
    note: "冬の新刊を制作中。年末の頒布でラボの一年を締めくくります。",
    noteEn: "A new winter book in production — closing the lab's year.",
  },
  {
    id: "comitia156", name: "COMITIA 156", jp: "コミティア156",
    iso: "2027-02-21", date: "2027.02.21", weekday: "SUN",
    venue: "Tokyo Big Sight", venueJp: "東京ビッグサイト 西ホール",
    booth: "TBA",
    note: "次の研究サイクル始動。新シリーズの構想を初お披露目する予定。",
    noteEn: "A new research cycle begins — first look at the next series.",
  },
];

Object.assign(window, { Placeholder, PUBLICATIONS, EVENTS });
