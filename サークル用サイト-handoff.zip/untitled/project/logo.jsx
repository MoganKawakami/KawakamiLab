/* logo.jsx — KAWAKAMI Lab. mark + lab iconography (vector) */
const { useId: _useId } = React;

/* The circuit-"K": a vertical spine, two diagonal traces branching from a
   central junction node, with terminal nodes — reads as both K and a lab schematic. */
function Logo({ size = 34, stroke = 3, gradient = true, mono = false, drawClass = "" }) {
  const id = _useId().replace(/:/g, "");
  const gid = "lg" + id;
  const col = mono ? "currentColor" : `url(#${gid})`;
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={drawClass}
         role="img" aria-label="KAWAKAMI Lab.">
      {!mono && (
        <defs>
          <linearGradient id={gid} x1="8" y1="6" x2="42" y2="44" gradientUnits="userSpaceOnUse">
            <stop stopColor="var(--c-primary)" />
            <stop offset="0.5" stopColor="var(--c-secondary)" />
            <stop offset="1" stopColor="var(--c-deep)" />
          </linearGradient>
        </defs>
      )}
      {/* spine */}
      <path d="M15 7V41" stroke={col} strokeWidth={stroke} strokeLinecap="round" />
      {/* upper diagonal trace */}
      <path d="M15 24 L34 8" stroke={col} strokeWidth={stroke} strokeLinecap="round" />
      {/* lower diagonal trace, stepped like a circuit */}
      <path d="M15 24 L27 34 L34 40" stroke={col} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" />
      {/* nodes */}
      <circle cx="15" cy="24" r="3.4" fill={col} />
      <circle cx="34" cy="8" r="3" fill={mono ? "currentColor" : "var(--c-primary)"} />
      <circle cx="34" cy="40" r="3" fill={mono ? "currentColor" : "var(--c-deep)"} />
      <circle cx="27" cy="34" r="2.1" fill={mono ? "currentColor" : "var(--c-secondary)"} />
      <circle cx="15" cy="7" r="2.1" fill={mono ? "currentColor" : "var(--c-primary)"} />
      <circle cx="15" cy="41" r="2.1" fill={mono ? "currentColor" : "var(--c-secondary)"} />
    </svg>
  );
}

/* ---- Process icons (geometric, lab-flavoured) ---- */
function IconResearch({ size = 52 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 52 52" fill="none">
      <circle cx="23" cy="23" r="13" stroke="var(--c-deep)" strokeWidth="2.4" />
      <path d="M32.5 32.5L43 43" stroke="var(--c-primary)" strokeWidth="3" strokeLinecap="round" />
      <path d="M23 17v12M17 23h12" stroke="var(--c-secondary)" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}
function IconDesign({ size = 52 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 52 52" fill="none">
      <rect x="9" y="9" width="34" height="34" rx="4" stroke="var(--c-deep)" strokeWidth="2.4" />
      <path d="M9 20h34M20 9v34" stroke="var(--c-secondary)" strokeWidth="1.6" opacity=".6" />
      <circle cx="20" cy="20" r="5" fill="var(--c-primary)" />
    </svg>
  );
}
function IconPublish({ size = 52 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 52 52" fill="none">
      <path d="M26 8v22" stroke="var(--c-deep)" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M26 8l-9 9M26 8l9 9" stroke="var(--c-primary)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12 32v8a3 3 0 003 3h22a3 3 0 003-3v-8" stroke="var(--c-secondary)" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

/* ---- Decorative floating shapes ---- */
function ShapeCrystal({ size = 120 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none">
      <polygon points="60,8 102,42 84,104 36,104 18,42" fill="none" stroke="var(--c-primary)" strokeWidth="1.4" opacity=".8" />
      <polygon points="60,8 84,104 60,60" fill="color-mix(in oklab, var(--c-secondary) 22%, transparent)" />
      <polygon points="60,8 36,104 60,60" fill="color-mix(in oklab, var(--c-primary) 14%, transparent)" />
      <path d="M18 42L60 60L102 42M60 60v44" stroke="var(--c-deep)" strokeWidth="1" opacity=".5" />
    </svg>
  );
}
function ShapeRing({ size = 100 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r="46" stroke="var(--c-primary)" strokeWidth="1.2" strokeDasharray="3 7" opacity=".7" />
      <circle cx="50" cy="50" r="30" stroke="var(--c-deep)" strokeWidth="1.4" opacity=".5" />
      <circle cx="50" cy="4" r="3" fill="var(--c-secondary)" />
      <circle cx="50" cy="50" r="4" fill="var(--c-primary)" />
    </svg>
  );
}
function ShapeNodes({ size = 130 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 130 130" fill="none">
      <path d="M20 20L65 50L110 24M65 50V110M65 50L30 96" stroke="var(--c-deep)" strokeWidth="1.2" opacity=".55" />
      <circle cx="20" cy="20" r="4" fill="var(--c-primary)" />
      <circle cx="110" cy="24" r="4" fill="var(--c-secondary)" />
      <circle cx="65" cy="50" r="5.5" fill="none" stroke="var(--c-deep)" strokeWidth="1.6" />
      <circle cx="65" cy="110" r="4" fill="var(--c-secondary)" />
      <circle cx="30" cy="96" r="3.2" fill="var(--c-primary)" />
    </svg>
  );
}
function ShapePlus({ size = 60 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none">
      <path d="M30 8v44M8 30h44" stroke="var(--c-primary)" strokeWidth="1.4" opacity=".6" />
      <rect x="22" y="22" width="16" height="16" stroke="var(--c-deep)" strokeWidth="1.4" fill="none" transform="rotate(45 30 30)" />
    </svg>
  );
}

Object.assign(window, {
  Logo, IconResearch, IconDesign, IconPublish,
  ShapeCrystal, ShapeRing, ShapeNodes, ShapePlus,
});
