/* mobile-app.jsx — root for the phone-optimized site */
const { useState: useS, useEffect: useE, useCallback: useC } = React;

function MApp() {
  const [loaded, setLoaded] = useS(false);
  const [menu, setMenu] = useS(false);
  const [openIndex, setOpenIndex] = useS(null);

  /* loader */
  useE(() => { const id = setTimeout(() => setLoaded(true), 1400); return () => clearTimeout(id); }, []);

  /* reveals */
  useE(() => {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.14, rootMargin: "0px 0px -6% 0px" });
    document.querySelectorAll(".reveal:not(.in)").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [loaded]);

  /* scroll progress + nav state */
  useE(() => {
    const bar = document.getElementById("mprogress");
    const nav = document.getElementById("mnav");
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      const p = h > 0 ? window.scrollY / h : 0;
      if (bar) bar.style.transform = `scaleX(${p})`;
      if (nav) nav.classList.toggle("scrolled", window.scrollY > 30);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* lock body when menu or gallery open */
  useE(() => {
    document.body.classList.toggle("locked", menu || openIndex != null);
  }, [menu, openIndex]);

  const jump = useC((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const y = el.getBoundingClientRect().top + window.scrollY - (id === "top" ? 0 : 56);
    window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
  }, []);

  const open = useC((i) => setOpenIndex(i), []);
  const close = useC(() => setOpenIndex(null), []);
  const nav = useC((dir) => setOpenIndex((i) => (i == null ? i : (i + dir + PUBLICATIONS.length) % PUBLICATIONS.length)), []);

  useE(() => {
    if (openIndex == null) return;
    const onKey = (e) => {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowRight") nav(1);
      else if (e.key === "ArrowLeft") nav(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex, close, nav]);

  return (
    <React.Fragment>
      <div className={"loader" + (loaded ? " gone" : "")}>
        <div className="loader__inner">
          <div className="draw"><Logo size={56} stroke={2.6} /></div>
          <div className="loader__bar"><i /></div>
          <div className="loader__txt">Initializing Lab.</div>
        </div>
      </div>

      <div className="scroll-progress" id="mprogress" />

      <MNav open={menu} setOpen={setMenu} onJump={jump} />
      <main>
        <MHero onJump={jump} />
        <MMarquee />
        <MAbout />
        <MPublications onOpen={open} />
        <MEvents />
      </main>
      <MFooter onJump={jump} />

      {openIndex != null && (
        <MExperience pub={PUBLICATIONS[openIndex]} index={openIndex} total={PUBLICATIONS.length} onClose={close} onNav={nav} />
      )}
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<MApp />);
