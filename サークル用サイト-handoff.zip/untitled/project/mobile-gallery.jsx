/* mobile-gallery.jsx — full-screen publication experience (phone) */
const { useEffect: _mgEffect, useState: _mgState, useRef: _mgRef } = React;

function MExperience({ pub, index, total, onClose, onNav }) {
  const [swapKey, setSwapKey] = _mgState(0);
  const drag = _mgRef({ x: 0, a: false });
  _mgEffect(() => { setSwapKey(k => k + 1); }, [pub.id]);

  const onDown = (e) => { drag.current = { x: e.touches ? e.touches[0].clientX : e.clientX, a: true }; };
  const onUp = (e) => {
    if (!drag.current.a) return;
    const x = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
    const dx = x - drag.current.x; drag.current.a = false;
    if (dx < -50) onNav(1); else if (dx > 50) onNav(-1);
  };

  return (
    <div className="mexp mexp-enter" role="dialog" aria-modal="true">
      <div className="mexp__scrim" aria-hidden="true">
        <div className="blob b1" /><div className="blob b2" /><div className="blob b3" />
      </div>

      <header className="mexp__bar">
        <span className="id">SPEC {String(index + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
        <nav className="mexp__nav">
          <button className="mexp__btn" aria-label="Previous" onClick={() => onNav(-1)}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <button className="mexp__btn" aria-label="Next" onClick={() => onNav(1)}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <button className="mexp__btn mexp__btn--close" aria-label="Close" onClick={onClose}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          </button>
        </nav>
      </header>

      <div className="mexp__body" onTouchStart={onDown} onTouchEnd={onUp}>
        <div className="mexp__inner" key={swapKey}>
          <div className="mexp__cover">
            <Placeholder ratio={pub.ratio} label={pub.title} sub={pub.jp} from={pub.from} to={pub.to} big />
          </div>
          <div className="mexp__detail">
            <div className="eyebrow klabel">{pub.upcoming ? "Upcoming Release" : "From the Archive"}</div>
            <h2>{pub.title}</h2>
            <div className="jp">{pub.jp}</div>
            <p className="desc">{pub.desc}<span className="jp">{pub.descJp}</span></p>
            <dl className="spec">
              <div><dt>Released</dt><dd>{pub.date}</dd></div>
              <div className="price-cell"><dt>{pub.priceJp} / Price</dt><dd>{pub.price}</dd></div>
              <div><dt>Distributed at</dt><dd>{pub.event}</dd></div>
              <div><dt>Format</dt><dd>{pub.format}</dd></div>
            </dl>
            <div className="tags">{pub.tags.map(t => <span className="tag" key={t}>#{t}</span>)}</div>
            <div className="previews">
              <span className="lab-tag">Preview Plates — 試し読み</span>
              <div className="previews__grid">
                {pub.previews.map((p, i) => <div className="thumb" key={i}><Placeholder ratio={1.3} label={p} from={pub.from} to={pub.to} /></div>)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MExperience });
