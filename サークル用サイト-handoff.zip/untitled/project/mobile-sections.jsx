/* mobile-sections.jsx — phone-optimized sections, reusing desktop design tokens */
const { useState: _mState, useEffect: _mEffect, useRef: _mRef } = React;

const M_LINKS = [
  { en: "About", jp: "概要", id: "about" },
  { en: "Profile", jp: "主宰", id: "profile" },
  { en: "Publications", jp: "刊行物", id: "publications" },
  { en: "Events", jp: "開催情報", id: "events" },
  { en: "Contact", jp: "連絡先", id: "contact" },
];

/* ---------------- NAV + slide-down menu ---------------- */
function MNav({ open, setOpen, onJump }) {
  return (
    <React.Fragment>
      <header className="mnav" id="mnav">
        <div className="mnav__brand">
          <Logo size={30} />
          <b>KAWAKAMI Lab.</b>
        </div>
        <button className="mnav__burger" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(o => !o)}>
          {open ? (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          ) : (
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          )}
        </button>
      </header>

      <div className={"mmenu" + (open ? " open" : "")}>
        <div className="mmenu__scrim" aria-hidden="true">
          <div className="blob b1" /><div className="blob b2" />
        </div>
        <nav className="mmenu__links">
          {M_LINKS.map((l, i) => (
            <a key={l.id} href={"#" + l.id} onClick={(e) => { e.preventDefault(); onJump(l.id); setOpen(false); }}>
              {l.en}<span className="jp">{l.jp}</span>
              <span className="idx">0{i + 1}</span>
            </a>
          ))}
        </nav>
        <button className="btn btn--primary mmenu__cta" onClick={() => { onJump("publications"); setOpen(false); }}>
          Browse Works <span className="arrow">→</span>
        </button>
        <div className="mmenu__foot">
          <span>想像が、視覚芸術になる場所。</span>
          <span>© 2026</span>
        </div>
      </div>
    </React.Fragment>
  );
}

/* ---------------- HERO ---------------- */
function MHero({ onJump }) {
  return (
    <section className="mhero" id="top">
      <div className="mhero__bg">
        <div className="blob b1" /><div className="blob b2" /><div className="blob b3" />
      </div>
      <div className="mhero__grid" />
      <div className="mshape bob" style={{ top: "13%", right: "6%" }}><ShapeRing size={66} /></div>
      <div className="mshape spin" style={{ bottom: "20%", left: "7%" }}><ShapePlus size={40} /></div>

      <div className="m-container mhero__inner">
        <div className="eyebrow reveal in">Anime Illustration Studio · 創作研究室</div>
        <h1 className="reveal in d1">KAWAKAMI<br />Lab<span className="dot">.</span></h1>
        <p className="mhero__jp reveal in d2">推しを信じて描く。</p>
        <p className="mhero__en reveal in d3">Drawing what we love, with conviction — a circle devoted to illustrating our favorite characters.</p>

        <div className="mhero__card reveal in d3">
          <div className="cap"><span className="t">FIG.01 — FEATURED</span><span className="t r">2024</span></div>
          <div className="art"><Placeholder ratio={1.25} label="CHROMA" sub="彩光" from="#5fc8ff" to="#2563EB" big /></div>
          <div className="cap"><span className="t" style={{ color: "var(--c-ink)", fontFamily: "var(--font-display)", fontSize: 13, letterSpacing: 0 }}>Original Illustration</span><span className="t">A4 · 64P</span></div>
        </div>

        <div className="mhero__actions reveal in d4">
          <button className="btn btn--primary" onClick={() => onJump("publications")}>Explore Publications <span className="arrow">→</span></button>
          <button className="btn btn--ghost" onClick={() => onJump("about")}>About the Lab</button>
        </div>

        <div className="mscroll-cue reveal in d4"><span>Scroll</span><div className="track" /></div>
      </div>
    </section>
  );
}

/* ---------------- MARQUEE ---------------- */
function MMarquee() {
  const words = ["ANIME ILLUSTRATION", "ORIGINAL ARTWORK", "FAN ART", "CONCEPT DESIGN", "VISUAL RESEARCH", "DOUJIN PUBLISHING"];
  const set = [...words, ...words];
  return (
    <div className="mmarquee" aria-hidden="true">
      <div className="mmarquee__track">{set.map((w, i) => <span key={i}>{w}</span>)}</div>
    </div>
  );
}

/* ---------------- PROFILE deck ---------------- */
const M_PROF_FACETS = [
  { key: "basics", label: "Basics", jp: "基本情報", rows: [
    { dt: "年齢 / Age", dd: "20代前半", jp: true },
    { dt: "性別 / Gender", dd: "男性", jp: true },
    { dt: "居住地 / Based in", dd: "日本, 愛知", jp: true },
    { dt: "活動開始 / Since", dd: "2019" },
  ] },
  { key: "hobbies", label: "Hobbies", jp: "趣味",
    chips: ["お絵描き", "デジタル作画", "レトロゲーム", "映画鑑賞", "カメラ・写真", "珈琲", "インディー音楽", "美術館めぐり"] },
  { key: "oshi", label: "Favorites", jp: "推しキャラ", favs: [
    { name: "推しキャラ ①", code: "OSHI 01", from: "#5fc8ff", to: "#2563EB" },
    { name: "推しキャラ ②", code: "OSHI 02", from: "#3bd6e6", to: "#1f7fe0" },
    { name: "推しキャラ ③", code: "OSHI 03", from: "#7dd3fc", to: "#0ea5e9" },
  ], quote: "光と色がきれいに映えるキャラクターが好きです。" },
  { key: "setup", label: "Studio", jp: "制作環境", rows: [
    { dt: "Hardware", dd: "iPad Pro / 液晶タブレット", jp: true },
    { dt: "Software", dd: "CLIP STUDIO PAINT" },
    { dt: "好きな色 / Color", dd: "Cyan ・ 水色", jp: true },
    { dt: "1日の作画 / Per day", dd: "3〜5時間", jp: true },
  ], quote: "「想像を、誰かの心に残る一枚に。」" },
];

function MProfile() {
  const [i, setI] = _mState(0);
  const [back, setBack] = _mState(false);
  const total = M_PROF_FACETS.length;
  const drag = _mRef({ x: 0, a: false });

  const go = (n, d) => {
    const ni = (n + total) % total;
    if (ni === i) return;
    setBack(d != null ? d < 0 : ni < i);
    setI(ni);
  };
  const onDown = (e) => { drag.current = { x: e.touches ? e.touches[0].clientX : e.clientX, a: true }; };
  const onUp = (e) => {
    if (!drag.current.a) return;
    const x = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
    const dx = x - drag.current.x; drag.current.a = false;
    if (dx < -45) go(i + 1, 1); else if (dx > 45) go(i - 1, -1);
  };

  return (
    <div className="mprof reveal d1">
      <aside className="mprof__card">
        <span className="idtag l">ID · LAB-0001</span>
        <span className="idtag r">サークル主 / FOUNDER</span>
        <div className="mprof__avatar-wrap">
          <span className="ring" />
          <div className="mprof__avatar"><span className="lbl">ICON</span><span className="sub">drop your icon</span></div>
        </div>
        <div className="mprof__name">川上モガん</div>
        <div className="mprof__handle">@kawakami_lab</div>
        <div className="mprof__role">サークル主</div>
        <div className="mprof__socials">
          <a href="#contact" aria-label="X / Twitter"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M3 3l7.5 9.5L3.5 21H6l6-7 5.5 7H21l-7.8-10L20.5 3H18l-5.4 6.4L8 3H3z" fill="currentColor"/></svg></a>
          <a href="#contact" aria-label="pixiv"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 21V6.5C9 5 10 4 12.5 4S16 5.4 16 7.4 14.6 11 12.2 11H10.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></a>
          <a href="#contact" aria-label="Mail"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.8"/><path d="M4 7l8 6 8-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg></a>
        </div>
      </aside>

      <div className="mprof__deck" onTouchStart={onDown} onTouchEnd={onUp} onPointerDown={onDown} onPointerUp={onUp}>
        <div className="mprof__deck-head">
          <span className="lab-tag2">Swipe Profile</span>
          <span className="ix">{String(i + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
        </div>
        <div className="mprof__deck-body">
          {M_PROF_FACETS.map((ff, idx) => (
            <div className={"mprof__facet" + (idx === i ? " is-active" : "") + (idx === i && back ? " toleft" : "")} key={ff.key} aria-hidden={idx !== i}>
              <h4>{ff.label}<span className="jp">{ff.jp}</span></h4>
              {ff.rows && (
                <dl className="pf-rows">
                  {ff.rows.map((r) => <div className="pf-row" key={r.dt}><dt>{r.dt}</dt><dd className={r.jp ? "jp" : ""}>{r.dd}</dd></div>)}
                </dl>
              )}
              {ff.chips && <div className="pf-chips">{ff.chips.map((c) => <span className="pf-chip" key={c}><i />{c}</span>)}</div>}
              {ff.favs && (
                <div className="pf-favs">
                  {ff.favs.map((v) => (
                    <div className="pf-fav" key={v.code}>
                      <div className="pf-fav-art"><Placeholder ratio={1} label={v.code} from={v.from} to={v.to} /></div>
                      <div className="cap">{v.name}<small>{v.code}</small></div>
                    </div>
                  ))}
                </div>
              )}
              {ff.quote && <div className="pf-quote">{ff.quote}</div>}
            </div>
          ))}
        </div>
        <div className="mprof__deck-foot">
          <div className="mprof__dots">
            {M_PROF_FACETS.map((ff, idx) => <button key={ff.key} className={idx === i ? "on" : ""} aria-label={ff.label} onClick={() => go(idx)} />)}
          </div>
          <div className="mprof__deck-nav">
            <button className="rbtn" aria-label="Previous" onClick={() => go(i - 1, -1)}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
            <button className="rbtn" aria-label="Next" onClick={() => go(i + 1, 1)}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- ABOUT ---------------- */
function MAbout() {
  const stats = [
    { n: "6+", l: "Publications", jp: "刊行物" },
    { n: "2019", l: "Established", jp: "設立" },
    { n: "12", l: "Events", jp: "頒布実績" },
    { n: "∞", l: "In progress", jp: "進行中" },
  ];
  return (
    <section className="m-section mabout" id="about">
      <div className="m-container">
        <div className="reveal">
          <div className="eyebrow">About KAWAKAMI Lab.</div>
          <h2 className="grad-text">A laboratory<br />for visual art.</h2>
        </div>
        <div className="mabout__lead reveal d1">
          <p><span className="jp">KAWAKAMI Lab.（カワカミ・ラボ）は、推しを描くためのサークルです。</span></p>
          <p>We are a doujin circle dedicated to <strong>drawing the characters we love</strong> — through anime illustration, original artwork, and fan art.</p>
        </div>

        <div className="mprofhead reveal" id="profile">
          <div className="eyebrow">Profile · サークル主紹介</div>
          <h3 className="grad-text">Meet the founder</h3>
        </div>
        <MProfile />

        <div className="mstats">
          {stats.map((s, i) => (
            <div className={"mstat reveal d" + (i % 4 + 1)} key={s.l}>
              <div className="n grad-text">{s.n}</div>
              <div className="l">{s.l}<span className="jp">{s.jp}</span></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- PUBLICATIONS ---------------- */
function MPublications({ onOpen }) {
  return (
    <section className="m-section mpubs" id="publications">
      <div className="m-container">
        <div className="mpubs__head reveal">
          <div className="eyebrow">Publications · 刊行物</div>
          <h2 className="grad-text">Selected Works</h2>
          <p className="sub">作品をタップすると、フルスクリーンの展示ビューが開きます。</p>
        </div>
        <div className="mpubs__list">
          {PUBLICATIONS.map((p, i) => (
            <article className={"mpub reveal d" + (i % 3 + 1)} key={p.id} onClick={() => onOpen(i)}>
              <div className="mpub__cover">
                <Placeholder ratio={1.2} label={p.title} sub={p.jp} from={p.from} to={p.to} />
                <span className="yr">{p.year}</span>
                <span className="open"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M7 17L17 7M9 7h8v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></span>
              </div>
              <div className="mpub__meta">
                <h3>{p.title}</h3>
                <div className="jp">{p.jp}</div>
                <div className="row"><span className="type">{p.type}</span><span className="price">{p.price}</span></div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- EVENTS ---------------- */
const M_MONTHS = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
function mDaysUntil(iso) {
  const now = new Date();
  const d = new Date(iso + "T00:00:00");
  return Math.ceil((d - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
}

const M_WEEK = ["SUN","MON","TUE","WED","THU","FRI","SAT"];
const M_PAST_EVENTS = [
  { id: "cm108", name: "Comic Market 108", iso: "2026-08-30", venueJp: "東京ビッグサイト 東地区", booth: "東7 か-21a",
    note: "既刊フルラインナップ＋新作アクリルスタンド・ポストカードを頒布しました。" },
  { id: "comitia152", name: "COMITIA 152", iso: "2026-08-17", venueJp: "東京ビッグサイト 西1・2ホール", booth: "あ-12b",
    note: "新刊『HALATION / ハレーション』を頒布しました。ご来場ありがとうございました。" },
  { id: "comitia151", name: "COMITIA 151", iso: "2026-05-05", venueJp: "東京ビッグサイト 西ホール", booth: "き-08a",
    note: "『CHROMA / 彩光』再版と新作ポストカードを頒布しました。" },
  { id: "cm107", name: "Comic Market 107", iso: "2025-12-30", venueJp: "東京ビッグサイト 東地区", booth: "東5 ね-33b",
    note: "冬の新刊とラフ集『PROTOTYPE 0』を頒布しました。" },
  { id: "comitia150", name: "COMITIA 150", iso: "2025-11-24", venueJp: "東京ビッグサイト 西ホール", booth: "す-19a",
    note: "『試作零号 / PROTOTYPE 0』初頒布。たくさんの方に手に取っていただきました。" },
];

function MEvents() {
  const EVENTS = M_PAST_EVENTS;
  const [active, setActive] = _mState(0);
  const [dir, setDir] = _mState(1);
  const total = EVENTS.length;
  const drag = _mRef({ x: 0, a: false });

  const go = (i, d) => {
    const ni = Math.max(0, Math.min(total - 1, i));
    if (ni === active) return;
    setDir(d != null ? d : (ni > active ? 1 : -1));
    setActive(ni);
  };
  const onDown = (e) => { drag.current = { x: e.touches ? e.touches[0].clientX : e.clientX, a: true }; };
  const onUp = (e) => {
    if (!drag.current.a) return;
    const x = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
    const dx = x - drag.current.x; drag.current.a = false;
    if (dx < -45) go(active + 1, 1); else if (dx > 45) go(active - 1, -1);
  };

  const ev = EVENTS[active];
  const d = new Date(ev.iso + "T00:00:00");
  const dd = mDaysUntil(ev.iso);
  const progress = total > 1 ? (active / (total - 1)) * 100 : 0;

  return (
    <section className="m-section mabout" id="events" style={{ background: "var(--c-bg)" }}>
      <div className="m-container">
        <div className="mpubs__head reveal">
          <div className="eyebrow">Events · 参加したイベント</div>
          <h2 className="grad-text">Where we've been</h2>
          <p className="sub">これまでに参加したイベントの記録です。スワイプ・矢印・ドットで切り替えられます。</p>
        </div>

        <div className={"mev reveal d1 " + (dir > 0 ? "mev-next" : "mev-prev")}>
          <div className="mev__stage" onTouchStart={onDown} onTouchEnd={onUp} onPointerDown={onDown} onPointerUp={onUp}>
            <div className="mev__side" key={"s" + ev.id}>
              <div className="mev__date">
                <span className="day">{String(d.getDate()).padStart(2, "0")}</span>
                <span className="my"><span className="month">{M_MONTHS[d.getMonth()]}</span><span className="yw">{d.getFullYear()} · {M_WEEK[d.getDay()]}</span></span>
              </div>
              <span className="mev__count"><b>{Math.max(0, -dd)}</b> 日前に参加</span>
            </div>
            <div className="mev__main" key={"m" + ev.id}>
              <span className="mev__badge"><span className="pip" />{active === 0 ? "Latest · 直近の参加" : `Archive ${active + 1} / ${total}`}</span>
              <h3 className="mev__name">{ev.name}</h3>
              <dl className="mev__rows">
                <div className="mev__row"><dt>Venue · 会場</dt><dd><span className="jp">{ev.venueJp}</span></dd></div>
                <div className="mev__row"><dt>Booth · 配置</dt><dd><span className="booth">{ev.booth}</span></dd></div>
                <div className="mev__row"><dt>Notes · 頒布物</dt><dd><span className="jp">{ev.note}</span></dd></div>
              </dl>
            </div>
          </div>

          <div className="mev__rail">
            <button className="rbtn" aria-label="Previous event" disabled={active === 0} onClick={() => go(active - 1, -1)}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
            <div className="mev__track">
              <div className="mev__line"><i style={{ width: progress + "%" }} /></div>
              <div className="mev__node-row">
                {EVENTS.map((e, i) => (
                  <button key={e.id} className={"mev__node" + (i === active ? " active" : "") + (i < active ? " past" : "")} onClick={() => go(i)} aria-label={e.name}>
                    <span className="mev__dot" />
                  </button>
                ))}
              </div>
            </div>
            <button className="rbtn" aria-label="Next event" disabled={active === total - 1} onClick={() => go(active + 1, 1)}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
          <div className="mev__hint">← Swipe · Tap a node →</div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function MFooter({ onJump }) {
  return (
    <footer className="mfooter" id="contact">
      <div className="mfooter__glow" />
      <div className="m-container mfooter__inner">
        <h2 className="mfooter__cta reveal">Let's make imagination visible together.
          <span className="jp">コラボレーション・寄稿・お問い合わせはお気軽に。</span>
        </h2>
        <button className="btn btn--primary reveal d1" onClick={() => onJump("top")} style={{ background: "var(--grad-sky)" }}>
          Get in touch <span className="arrow">→</span>
        </button>
        <div className="mfooter__grid">
          <div className="mfooter__col">
            <div className="brandline"><Logo size={28} mono /><b>KAWAKAMI Lab.</b></div>
            <p>Where imagination becomes visual art. A creative laboratory publishing anime illustration & original artwork.</p>
          </div>
          <div className="mfooter__col">
            <h4>Navigate</h4>
            <a href="#about" onClick={(e) => { e.preventDefault(); onJump("about"); }}>About / 概要</a>
            <a href="#profile" onClick={(e) => { e.preventDefault(); onJump("profile"); }}>Profile / 主宰紹介</a>
            <a href="#publications" onClick={(e) => { e.preventDefault(); onJump("publications"); }}>Publications / 刊行物</a>
            <a href="#events" onClick={(e) => { e.preventDefault(); onJump("events"); }}>Events / 開催情報</a>
          </div>
          <div className="mfooter__col">
            <h4>Connect</h4>
            <a href="#contact">X / Twitter</a>
            <a href="#contact">pixiv</a>
          </div>
        </div>
        <div className="mfooter__bottom">
          <span>© 2026 KAWAKAMI Lab. — All artwork reserved.</span>
          <span>想像が、視覚芸術になる場所。</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { MNav, MHero, MMarquee, MAbout, MPublications, MEvents, MFooter });
