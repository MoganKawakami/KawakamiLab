/* sections.jsx — Nav, Hero, Marquee, About, Publications, Footer */
const { useEffect: _sUseEffect, useState: _sUseState } = React;

/* ---------------- NAV ---------------- */
function Nav({ onJump }) {
  const links = [
    { en: "About", jp: "概要", id: "about" },
    { en: "Profile", jp: "主宰", id: "profile" },
    { en: "Publications", jp: "刊行物", id: "publications" },
    { en: "Events", jp: "開催情報", id: "events" },
  ];
  return (
    <header className="nav" id="nav">
      <a className="nav__brand" href="#top" onClick={(e) => { e.preventDefault(); onJump("top"); }}>
        <Logo size={34} />
        <span className="wordmark">
          <b>KAWAKAMI Lab.</b>
          <span>Creative Laboratory</span>
        </span>
      </a>
      <nav className="nav__links">
        {links.map(l => (
          <a key={l.id} href={"#" + l.id} onClick={(e) => { e.preventDefault(); onJump(l.id); }}>
            {l.en}<span className="jp">{l.jp}</span>
          </a>
        ))}
      </nav>
      <button className="nav__cta" onClick={() => onJump("publications")}>Browse Works</button>
      <button className="nav__burger" aria-label="Menu" onClick={() => onJump("publications")}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
      </button>
    </header>
  );
}

/* ---------------- HERO ---------------- */
function Hero({ onJump }) {
  return (
    <section className="hero" id="top">
      <div className="hero__bg" data-par-layer>
        <div className="blob b1" data-par="0.06" />
        <div className="blob b2" data-par="0.04" />
        <div className="blob b3" data-par="0.08" />
      </div>
      <div className="hero__grid" data-par="0.02" />

      {/* floating lab shapes */}
      <div className="shape" style={{ top: "16%", left: "6%" }} data-par="0.14"><div className="bob"><ShapeRing size={92} /></div></div>
      <div className="shape" style={{ top: "62%", left: "11%" }} data-par="0.20"><div className="spin"><ShapePlus size={56} /></div></div>
      <div className="shape" style={{ top: "24%", right: "8%" }} data-par="0.10"><div className="bob"><ShapeNodes size={120} /></div></div>
      <div className="shape" style={{ bottom: "14%", right: "20%" }} data-par="0.24"><div className="spin-rev"><ShapePlus size={40} /></div></div>

      <div className="container hero__inner">
        <div className="hero__copy">
          <div className="eyebrow hero__eyebrow reveal in">Anime Illustration Studio · 創作研究室</div>
          <h1 className="reveal in d1">
            KAWAKAMI<br /><span className="lab">Lab</span><span className="dot">.</span>
          </h1>
          <p className="hero__jp reveal in d2">想像が、視覚芸術になる場所。</p>
          <p className="hero__en reveal in d3">Where imagination becomes visual art — a creative laboratory researching, designing, and publishing visual experiences.</p>
          <div className="hero__actions reveal in d4">
            <button className="btn btn--primary" onClick={() => onJump("publications")}>
              Explore Publications <span className="arrow">→</span>
            </button>
            <button className="btn btn--ghost" onClick={() => onJump("about")}>About the Lab</button>
          </div>
        </div>

        <div className="hero__visual" data-par="0.05">
          <SpecimenCard />
        </div>
      </div>

      <div className="scroll-cue">
        <span>Scroll</span>
        <div className="track" />
      </div>
    </section>
  );
}

/* floating glass specimen card in hero */
function SpecimenCard() {
  return (
    <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
      <div className="bob" style={{
        position: "relative", width: 360, maxWidth: "100%",
        borderRadius: 22, padding: 14, background: "rgba(255,255,255,.6)",
        border: "1px solid var(--c-line)", backdropFilter: "blur(14px)",
        boxShadow: "0 50px 100px -50px rgba(11,27,46,.55)"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 6px 12px" }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: ".2em", color: "var(--c-muted)" }}>FIG.01 — FEATURED</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: ".2em", color: "var(--c-deep)" }}>2024</span>
        </div>
        <div style={{ borderRadius: 14, overflow: "hidden" }}>
          <Placeholder ratio={1.3} label="CHROMA" sub="彩光" from="#5fc8ff" to="#2563EB" big />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 6px 4px" }}>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 15 }}>Original Illustration</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--c-muted)" }}>A4 · 64P</span>
        </div>
      </div>
    </div>
  );
}

/* ---------------- MARQUEE ---------------- */
function Marquee() {
  const words = ["ANIME ILLUSTRATION", "ORIGINAL ARTWORK", "FAN ART", "CONCEPT DESIGN", "VISUAL RESEARCH", "DOUJIN PUBLISHING"];
  const set = [...words, ...words];
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee__track">
        {set.map((w, i) => <span key={i}>{w}</span>)}
      </div>
    </div>
  );
}

/* ---------------- PROFILE (circle owner, swipeable deck) ---------------- */
const PROF_FACETS = [
  {
    key: "basics", label: "Basics", jp: "基本情報",
    rows: [
      { dt: "年齢 / Age", dd: "20代後半", jp: true },
      { dt: "性別 / Gender", dd: "男性", jp: true },
      { dt: "居住地 / Based in", dd: "東京, 日本", jp: true },
      { dt: "活動開始 / Since", dd: "2019" },
    ],
  },
  {
    key: "hobbies", label: "Hobbies", jp: "趣味",
    chips: ["お絵描き", "デジタル作画", "レトロゲーム", "映画鑑賞", "カメラ・写真", "珈琲", "インディー音楽", "美術館めぐり"],
  },
  {
    key: "oshi", label: "Favorites", jp: "推しキャラ",
    favs: [
      { name: "推しキャラ ①", code: "OSHI 01", from: "#5fc8ff", to: "#2563EB" },
      { name: "推しキャラ ②", code: "OSHI 02", from: "#3bd6e6", to: "#1f7fe0" },
      { name: "推しキャラ ③", code: "OSHI 03", from: "#7dd3fc", to: "#0ea5e9" },
    ],
    quote: "光と色がきれいに映えるキャラクターが好きです。",
  },
  {
    key: "setup", label: "Studio", jp: "制作環境",
    rows: [
      { dt: "Hardware", dd: "iPad Pro / 液晶タブレット", jp: true },
      { dt: "Software", dd: "CLIP STUDIO PAINT" },
      { dt: "好きな色 / Color", dd: "Cyan ・ 水色", jp: true },
      { dt: "1日の作画 / Per day", dd: "3〜5時間", jp: true },
    ],
    quote: "「想像を、誰かの心に残る一枚に。」",
  },
];

function Profile() {
  const [i, setI] = _sUseState(0);
  const [back, setBack] = _sUseState(false);
  const total = PROF_FACETS.length;
  const drag = React.useRef({ x: 0, a: false });

  const go = (n, d) => {
    const ni = (n + total) % total;
    if (ni === i) return;
    setBack(d != null ? d < 0 : ni < i);
    setI(ni);
  };
  const onDown = (e) => { drag.current = { x: e.clientX, a: true }; };
  const onUp = (e) => {
    if (!drag.current.a) return;
    const dx = e.clientX - drag.current.x;
    drag.current.a = false;
    if (dx < -55) go(i + 1, 1);
    else if (dx > 55) go(i - 1, -1);
  };

  const f = PROF_FACETS[i];
  return (
    <div className="prof reveal d1">
      {/* left — ID card */}
      <aside className="prof__card">
        <span className="idtag">ID · LAB-0001</span>
        <span className="idtag r">主宰 / FOUNDER</span>
        <div className="prof__avatar-wrap">
          <span className="ring" />
          <div className="prof__avatar">
            <span className="lbl">ICON</span>
            <span className="sub">drop your icon</span>
          </div>
        </div>
        <div className="prof__name">KAWAKAMI</div>
        <div className="prof__handle">@kawakami_lab</div>
        <div className="prof__role">イラストレーター / サークル主</div>
        <div className="prof__socials">
          <a href="#contact" aria-label="X / Twitter"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M3 3l7.5 9.5L3.5 21H6l6-7 5.5 7H21l-7.8-10L20.5 3H18l-5.4 6.4L8 3H3z" fill="currentColor"/></svg></a>
          <a href="#contact" aria-label="pixiv"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 21V6.5C9 5 10 4 12.5 4S16 5.4 16 7.4 14.6 11 12.2 11H10.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></a>
          <a href="#contact" aria-label="Mail"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.8"/><path d="M4 7l8 6 8-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg></a>
        </div>
      </aside>

      {/* right — swipe deck */}
      <div className="prof__deck" onPointerDown={onDown} onPointerUp={onUp}>
        <div className="prof__deck-head">
          <span className="lab-tag2">Swipe Profile</span>
          <span className="ix">{String(i + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
        </div>

        <div className="prof__deck-body">
          {PROF_FACETS.map((ff, idx) => (
            <div className={"prof__facet" + (idx === i ? " is-active" : "") + (idx === i && back ? " toleft" : "")}
                 key={ff.key} aria-hidden={idx !== i}>
              <h4>{ff.label}<span className="jp">{ff.jp}</span></h4>

              {ff.rows && (
                <dl className="pf-rows">
                  {ff.rows.map((r) => (
                    <div className="pf-row" key={r.dt}>
                      <dt>{r.dt}</dt>
                      <dd className={r.jp ? "jp" : ""}>{r.dd}</dd>
                    </div>
                  ))}
                </dl>
              )}

              {ff.chips && (
                <div className="pf-chips">
                  {ff.chips.map((c) => <span className="pf-chip" key={c}><i />{c}</span>)}
                </div>
              )}

              {ff.favs && (
                <div className="pf-favs">
                  {ff.favs.map((v) => (
                    <div className="pf-fav" key={v.code}>
                      <div className="pf-fav-art"><Placeholder ratio={1} label={v.code} from={v.from} to={v.to} /></div>
                      <div className="cap">{v.name}<small>{v.code}</small></div>
                    </div>
                  ))}
                </div>
              )}

              {ff.quote && <div className="pf-quote">{ff.quote}</div>}
            </div>
          ))}
        </div>

        <div className="prof__deck-foot">
          <div className="prof__dots">
            {PROF_FACETS.map((ff, idx) => (
              <button key={ff.key} className={idx === i ? "on" : ""} aria-label={ff.label} onClick={() => go(idx)} />
            ))}
          </div>
          <span className="prof__foot-hint">← swipe · drag →</span>
          <div className="prof__deck-nav">
            <button className="ev__btn" aria-label="Previous" onClick={() => go(i - 1, -1)}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
            <button className="ev__btn" aria-label="Next" onClick={() => go(i + 1, 1)}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- ABOUT ---------------- */
function About() {
  const stats = [
    { n: "6+", l: "Publications", jp: "刊行物" },
    { n: "2019", l: "Established", jp: "設立" },
    { n: "12", l: "Events", jp: "頒布実績" },
    { n: "∞", l: "Ideas in progress", jp: "進行中" },
  ];
  return (
    <section className="section about" id="about">
      <div className="container">
        <div className="about__top">
          <div className="reveal">
            <div className="eyebrow">About KAWAKAMI Lab.</div>
            <h2 className="grad-text">A laboratory<br />for visual art.</h2>
          </div>
          <div className="about__lead reveal d1">
            <p><span className="jp">KAWAKAMI Lab.（カワカミ・ラボ）は、想像を視覚体験へと翻訳する創作研究室です。</span></p>
            <p>We are a doujin circle that operates like a studio — <strong>researching, designing, and publishing</strong> anime illustration, original artwork, and fan art with the rigor of a creative laboratory. Every release is an experiment in light and color, refined until imagination becomes something you can hold.</p>
          </div>
        </div>

        <div className="about__profhead reveal" id="profile">
          <div className="eyebrow">Profile · サークル主紹介</div>
          <h3 className="profh grad-text">Meet the founder</h3>
        </div>
        <Profile />

        <div className="stats">
          {stats.map((s, i) => (
            <div className={"stat reveal d" + (i + 1)} key={s.l}>
              <div className="n grad-text">{s.n}</div>
              <div className="l">{s.l}<span className="jp">{s.jp}</span></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- PUBLICATIONS ---------------- */
function Publications({ onOpen }) {
  return (
    <section className="section pubs" id="publications">
      <div className="container">
        <div className="pubs__head reveal">
          <div>
            <div className="eyebrow">Publications · 刊行物</div>
            <h2 className="grad-text">Selected Works</h2>
          </div>
          <p className="sub">A growing archive of art books, illustration collections, and concept works. Select any volume to enter its full exhibition.</p>
        </div>

        <div className="masonry">
          {PUBLICATIONS.map((p, i) => (
            <article className={"pub reveal d" + ((i % 4) + 1)} key={p.id} onClick={() => onOpen(i)}>
              <div className="pub__cover">
                <div className="art"><Placeholder ratio={p.ratio} label={p.title} sub={p.jp} from={p.from} to={p.to} /></div>
                <div className="shine" />
                <span className="yr">{p.year}</span>
                <span className="open">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M7 17L17 7M9 7h8v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
              </div>
              <div className="pub__meta">
                <h3>{p.title}</h3>
                <div className="jp">{p.jp}</div>
                <div className="row">
                  <span className="type">{p.type}</span>
                  <span className="price">{p.price}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- EVENTS (interactive sliding timeline) ---------------- */
const MONTHS = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
function daysUntil(iso) {
  const now = new Date();
  const d = new Date(iso + "T00:00:00");
  return Math.ceil((d - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
}

function Events() {
  const [active, setActive] = _sUseState(0);
  const [dir, setDir] = _sUseState(1);
  const total = EVENTS.length;
  const dragRef = React.useRef({ x: 0, active: false });

  const go = (i, d) => {
    const ni = Math.max(0, Math.min(total - 1, i));
    if (ni === active) return;
    setDir(d != null ? d : (ni > active ? 1 : -1));
    setActive(ni);
  };

  const onDown = (e) => { dragRef.current = { x: e.clientX, active: true }; };
  const onUp = (e) => {
    if (!dragRef.current.active) return;
    const dx = e.clientX - dragRef.current.x;
    dragRef.current.active = false;
    if (dx < -55) go(active + 1, 1);
    else if (dx > 55) go(active - 1, -1);
  };

  const ev = EVENTS[active];
  const d = new Date(ev.iso + "T00:00:00");
  const dd = daysUntil(ev.iso);
  const progress = total > 1 ? (active / (total - 1)) * 100 : 0;

  return (
    <section className="section events" id="events">
      <div className="container">
        <div className="pubs__head reveal">
          <div>
            <div className="eyebrow">Events · 今後のイベント予定</div>
            <h2 className="grad-text">Where to find us</h2>
          </div>
          <p className="sub">頒布参加予定のイベント一覧。レール上のノード・矢印・スワイプで切り替えられます。</p>
        </div>

        <div className={"ev reveal d1 " + (dir > 0 ? "ev-next" : "ev-prev")}>
          <div className="ev__stage" onPointerDown={onDown} onPointerUp={onUp}>
            <div className="ev__ghost" aria-hidden="true">{String(active + 1).padStart(2, "0")}</div>

            <div className="ev__main" key={"m" + ev.id}>
              <span className="ev__badge"><span className="pip" />{active === 0 ? "Next Event · 直近の参加" : `Event ${active + 1} / ${total}`}</span>
              <h3 className="ev__name">{ev.name}</h3>
              <div className="ev__namejp">{ev.jp}</div>
              <dl className="ev__rows">
                <div className="ev__row"><dt>Venue · 会場</dt><dd><span className="jp">{ev.venueJp}</span></dd></div>
                <div className="ev__row"><dt>Booth · 配置</dt><dd><span className="booth">{ev.booth}</span></dd></div>
                <div className="ev__row"><dt>Notes · 頒布物</dt><dd><span className="jp">{ev.note}</span></dd></div>
              </dl>
            </div>

            <div className="ev__side" key={"s" + ev.id}>
              <span className="month">{MONTHS[d.getMonth()]}</span>
              <span className="day">{String(d.getDate()).padStart(2, "0")}</span>
              <span className="yw">{d.getFullYear()} · {ev.weekday}</span>
              <span className={"ev__count" + (dd <= 30 ? " soon" : "")}>
                {dd > 0 ? <React.Fragment>あと <b>{dd}</b> 日</React.Fragment> : "開催中"}
              </span>
            </div>
          </div>

          <div className="ev__rail">
            <button className="ev__btn" aria-label="Previous event" disabled={active === 0} onClick={() => go(active - 1, -1)}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 5l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
            <div className="ev__track">
              <div className="ev__line"><i style={{ width: progress + "%" }} /></div>
              <div className="ev__node-row">
                {EVENTS.map((e, i) => (
                  <button key={e.id}
                    className={"ev__node" + (i === active ? " active" : "") + (i < active ? " past" : "")}
                    onClick={() => go(i)} aria-label={e.name}>
                    <span className="ev__dot" />
                    <span className="nd-date">{e.date.slice(5)}</span>
                    <span className="nd-name">{e.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <button className="ev__btn" aria-label="Next event" disabled={active === total - 1} onClick={() => go(active + 1, 1)}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
          <div className="ev__hint">← Drag · Swipe · Tap a node →</div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer({ onJump }) {
  return (
    <footer className="footer" id="contact">
      <div className="footer__glow" />
      <div className="container footer__inner">
        <h2 className="footer__cta reveal">
          Let's make imagination<br />visible together.
          <span className="jp">コラボレーション・寄稿・お問い合わせはお気軽に。</span>
        </h2>
        <button className="btn btn--primary reveal d1" onClick={() => onJump("top")} style={{ background: "var(--grad-sky)" }}>
          Get in touch <span className="arrow">→</span>
        </button>

        <div className="footer__grid">
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <Logo size={30} mono />
              <b style={{ fontFamily: "var(--font-display)", fontSize: 18 }}>KAWAKAMI Lab.</b>
            </div>
            <p style={{ color: "color-mix(in oklab, #fff 65%, transparent)", fontSize: 14, lineHeight: 1.7, maxWidth: "34ch", margin: 0 }}>
              Where imagination becomes visual art. A creative laboratory publishing anime illustration & original artwork.
            </p>
          </div>
          <div>
            <h4>Navigate</h4>
            <a href="#about" onClick={(e) => { e.preventDefault(); onJump("about"); }}>About / 概要</a>
            <a href="#publications" onClick={(e) => { e.preventDefault(); onJump("publications"); }}>Publications / 刊行物</a>
            <a href="#events" onClick={(e) => { e.preventDefault(); onJump("events"); }}>Events / 開催情報</a>
            <a href="#profile" onClick={(e) => { e.preventDefault(); onJump("profile"); }}>Profile / 主宰紹介</a>
          </div>
          <div>
            <h4>Connect</h4>
            <a href="#contact">X / Twitter</a>
            <a href="#contact">pixiv</a>
          </div>
        </div>

        <div className="footer__bottom">
          <span>© 2026 KAWAKAMI Lab. — All artwork reserved.</span>
          <span>想像が、視覚芸術になる場所。</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { Nav, Hero, Marquee, About, Publications, Events, Footer });
